To run this application please follow these steps:
1. Install Open Java JDK 22 or higher
2. Update path to config.properties file in runner.bat
3. Update path to DataImport.xls file in runner.bat
4. Update path to meclip-1.0.0.jar file in runner.bat
Run autoviewer by using command: ./runner.bat
Schedule autoviewer by using command: ./scheduler.bat